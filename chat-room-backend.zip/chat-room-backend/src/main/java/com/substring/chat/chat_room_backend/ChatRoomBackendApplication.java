package com.substring.chat.chat_room_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatRoomBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatRoomBackendApplication.class, args);
	}

}
