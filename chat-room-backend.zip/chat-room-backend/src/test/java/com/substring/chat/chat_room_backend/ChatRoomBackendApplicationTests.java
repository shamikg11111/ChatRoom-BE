package com.substring.chat.chat_room_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatRoomBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
